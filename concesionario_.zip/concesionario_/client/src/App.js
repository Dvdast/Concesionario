import { useEffect, useState } from "react";
import VehiculoForm from "./components/VehiculoForm";
import VehiculoTable from "./components/VehiculoTable";
import Estadisticas from "./components/Estadisticas";
import "./App.css";

function App() {
  const [vehiculos, setVehiculos] = useState([]);
  const [error, setError] = useState(null);
  const [vehiculoEditando, setVehiculoEditando] = useState(null);

  const cargarVehiculos = () => {
    fetch("http://localhost:5000/api/vehiculos")
      .then((res) => {
        if (!res.ok)
          throw new Error("Error al conectar con el servidor Express");
        return res.json();
      })
      .then((data) => {
        if (!Array.isArray(data)) throw new Error("Respuesta no válida");
        setVehiculos(data);
      })
      .catch((err) => {
        console.error("Error al cargar vehículos:", err.message);
        setError("No se pudieron cargar los vehículos.");
        setVehiculos([]);
      });
  };

  useEffect(() => {
    cargarVehiculos();
  }, []);

  const eliminarVehiculo = (id) => {
    fetch("http://localhost/concesionario_php/vehiculos.php", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    })
      .then((res) => {
        if (!res.ok) throw new Error("Error al eliminar el vehículo");
        return res.json();
      })
      .then(() => {
        cargarVehiculos();
      })
      .catch((err) => {
        console.error("Error al eliminar:", err.message);
      });
  };

  return (
    <div className="container">
      <h1>GESTIÓN DE VEHÍCULOS</h1>
      {error && <div className="alert">{error}</div>}
      <VehiculoForm
        onVehiculoAñadido={cargarVehiculos}
        vehiculoParaEditar={vehiculoEditando}
        limpiarEdicion={() => setVehiculoEditando(null)}
        vehiculos={vehiculos}
      />
      <VehiculoTable
        vehiculos={vehiculos}
        onEliminar={eliminarVehiculo}
        onEditar={setVehiculoEditando}
      />
      <Estadisticas vehiculos={vehiculos} />
    </div>
  );
}

export default App;
