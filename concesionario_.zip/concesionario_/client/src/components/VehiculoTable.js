function VehiculoTable({ vehiculos, onEliminar, onEditar }) {
  return (
    <div>
      <h2>Lista de Vehículos</h2>
      {vehiculos.length === 0 ? (
        <p>No hay vehículos disponibles.</p>
      ) : (
        <table className="table">
          <thead>
            <tr>
              <th>Nº Chasis</th>
              <th>Marca</th>
              <th>Modelo</th>
              <th>Color</th>
              <th>Potencia</th>
              <th>Fecha de Fabricación</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {vehiculos.map((v) => (
              <tr key={v.id}>
                <td>{v.numChasis}</td>
                <td>{v.marca}</td>
                <td>{v.modelo}</td>
                <td>{v.color}</td>
                <td>{v.potencia}</td>
                <td>{v.fechaFabricacion}</td>
                <td>
                  <button
                    className="btn btn-warning btn-sm me-2"
                    onClick={() => onEditar(v)}
                  >
                    Editar✏️
                  </button>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => onEliminar(v.id)}
                  >
                    Eliminar🗑️
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default VehiculoTable;
