import { useState, useMemo } from "react";

function Estadisticas({ vehiculos }) {
  const [marcaSeleccionada, setMarcaSeleccionada] = useState("");

  //  calcular estadísticas
  const calcularStats = (lista) => {
    if (lista.length === 0) return { min: "-", max: "-", media: "-" };

    const potencias = lista.map((v) => Number(v.potencia));
    const total = potencias.reduce((a, b) => a + b, 0);
    const media = (total / potencias.length).toFixed(2);
    const min = Math.min(...potencias);
    const max = Math.max(...potencias);

    return { min, max, media };
  };

  //Filtrar vehículos por marca
  const vehiculosFiltrados = useMemo(() => {
    return marcaSeleccionada
      ? vehiculos.filter((v) => v.marca === marcaSeleccionada)
      : vehiculos;
  }, [vehiculos, marcaSeleccionada]);

  const statsGlobales = calcularStats(vehiculos);
  const statsMarca = calcularStats(vehiculosFiltrados);

  // Lista única de marcas
  const marcasUnicas = [...new Set(vehiculos.map((v) => v.marca))];

  return (
    <div style={{ marginTop: "2rem" }}>
      <h2>Estadísticas</h2>

      <div>
        <h3>Potencia total</h3>
        <ul>
          <li>Media: {statsGlobales.media}</li>
          <li>Mínima: {statsGlobales.min}</li>
          <li>Máxima: {statsGlobales.max}</li>
        </ul>
      </div>

      <div style={{ marginTop: "1rem" }}>
        <h3>Potencia por marca</h3>
        <select
          value={marcaSeleccionada}
          onChange={(e) => setMarcaSeleccionada(e.target.value)}
        >
          <option value="">-- Selecciona una marca --</option>
          {marcasUnicas.map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </select>

        {marcaSeleccionada && (
          <ul>
            <li>Media: {statsMarca.media}</li>
            <li>Mínima: {statsMarca.min}</li>
            <li>Máxima: {statsMarca.max}</li>
          </ul>
        )}
      </div>
    </div>
  );
}

export default Estadisticas;
