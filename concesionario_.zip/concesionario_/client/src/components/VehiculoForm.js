import { useState, useEffect, useContext } from "react";
import ValidacionesContext from "../context/ValidacionesContext";

function VehiculoForm({
  onVehiculoAñadido,
  vehiculoParaEditar,
  limpiarEdicion,
  vehiculos,
}) {
  const [form, setForm] = useState({
    numChasis: "",
    marca: "",
    modelo: "",
    color: "",
    potencia: "",
    fechaFabricacion: "",
  });
  const [error, setError] = useState("");

  const validacion = useContext(ValidacionesContext);

  useEffect(() => {
    if (vehiculoParaEditar) {
      setForm(vehiculoParaEditar);
    }
  }, [vehiculoParaEditar]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const validar = () => {
    const { numChasis, marca, modelo, color, potencia, fechaFabricacion } =
      form;

    if (!validacion.regexChasis.test(numChasis))
      return "El número de chasis debe tener 8 dígitos.";
    if (!validacion.regexTexto.test(marca))
      return "La marca solo puede contener letras.";
    if (!validacion.regexTextoNum.test(modelo)) return "Modelo inválido.";
    if (!validacion.regexTexto.test(color)) return "Color inválido.";
    if (isNaN(potencia) || Number(potencia) < 51)
      return "Potencia debe ser mayor a 50.";
    if (new Date(fechaFabricacion) > new Date()) return "Fecha no válida.";

    // Validación para evitar duplicados
    if (!form.id) {
      //Creando
      const yaExiste = vehiculos.some((v) => v.numChasis === form.numChasis);
      if (yaExiste) return "Ya existe un vehículo con ese número de chasis.";
    } else {
      //Editando
      const duplicado = vehiculos.some(
        (v) => v.numChasis === form.numChasis && v.id !== form.id
      );
      if (duplicado)
        return "Ese número de chasis ya está en uso por otro vehículo.";
    }

    return "";
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const mensajeError = validar();
    if (mensajeError) {
      setError(mensajeError);
      return;
    }

    const metodo = form.id ? "PUT" : "POST";

    fetch("http://localhost/concesionario_php/vehiculos.php", {
      method: metodo,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    })
      .then((res) => {
        if (!res.ok) throw new Error("Error al guardar");
        return res.json();
      })
      .then(() => {
        onVehiculoAñadido();
        setForm({
          numChasis: "",
          marca: "",
          modelo: "",
          color: "",
          potencia: "",
          fechaFabricacion: "",
        });
        setError("");
        limpiarEdicion();
      })
      .catch((err) => {
        setError("No se pudo guardar el vehículo.");
        console.error(err);
      });
  };

  return (
    <div className="card p-3 mb-4">
      <h2>{form.id ? "Editar vehículo" : "Añadir vehículo"}</h2>
      {error && <p className="alert">{error}</p>}
      <form onSubmit={handleSubmit} className="row g-3">
        <div className="col-md-4">
          <input
            name="numChasis"
            placeholder="Nº Chasis"
            className="form-control"
            value={form.numChasis}
            onChange={handleChange}
          />
        </div>
        <div className="col-md-4">
          <input
            name="marca"
            placeholder="Marca"
            className="form-control"
            value={form.marca}
            onChange={handleChange}
          />
        </div>
        <div className="col-md-4">
          <input
            name="modelo"
            placeholder="Modelo"
            className="form-control"
            value={form.modelo}
            onChange={handleChange}
          />
        </div>
        <div className="col-md-4">
          <input
            name="color"
            placeholder="Color"
            className="form-control"
            value={form.color}
            onChange={handleChange}
          />
        </div>
        <div className="col-md-4">
          <input
            name="potencia"
            placeholder="Potencia"
            type="number"
            className="form-control"
            value={form.potencia}
            onChange={handleChange}
          />
        </div>
        <div className="col-md-4">
          <input
            name="fechaFabricacion"
            type="date"
            className="form-control"
            value={form.fechaFabricacion}
            onChange={handleChange}
          />
        </div>
        <div className="col-12">
          <button type="submit" className="btn btn-primary me-2">
            {form.id ? "Actualizar" : "Guardar"}
          </button>
          {form.id && (
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => {
                limpiarEdicion();
                setForm({
                  numChasis: "",
                  marca: "",
                  modelo: "",
                  color: "",
                  potencia: "",
                  fechaFabricacion: "",
                });
              }}
            >
              Cancelar
            </button>
          )}
        </div>
      </form>
    </div>
  );
}

export default VehiculoForm;
