import { createContext } from "react";

const ValidacionContext = createContext({
  regexChasis: /^\d{8}$/, //chasis
  regexTexto: /^[a-zA-Z\s]+$/, // Marca y color
  regexTextoNum: /^[a-zA-Z0-9\s]+$/, // Modelo
});

export default ValidacionContext;
