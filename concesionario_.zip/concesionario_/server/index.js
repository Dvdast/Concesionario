const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Ruta de prueba
app.get("/api/mensaje", (req, res) => {
  res.json({ mensaje: "¡Bienvenido al concesionario!" });
});

// Ruta entre React y PHP
app.get("/api/vehiculos", async (req, res) => {
  try {
    //PHP en Apache
    const response = await fetch(
      "http://localhost/concesionario_php/vehiculos.php"
    );
    const text = await response.text();

    console.log(" Respuesta  PHP:", text);

    try {
      const data = JSON.parse(text);
      res.json(data);
    } catch (parseError) {
      console.error(" Error  JSON:", parseError.message);
      res.status(500).json({ error: "PHP no devolvió JSON válido" });
    }
  } catch (error) {
    console.error("Error al obtener vehículos desde PHP:", error.message);
    res.status(500).json({ error: "No se pudo obtener la lista de vehículos" });
  }
});

// iniciar  Express
app.listen(PORT, () => {
  console.log(`Express en: http://localhost:${PORT}`);
});
