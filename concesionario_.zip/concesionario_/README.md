# Concesionario

## Estructura

- `client/`:React
- `server/`:Express
- `concesionario_php/`:backend en PHP (copiar en XAMPP para que funcione)

## Cómo ejecutar

### 1. PHP (XAMPP)

- Copia la carpeta `concesionario_php` dentro de `C:\xampp\htdocs`
- Inicia Apache desde XAMPP
- Accede a `http://localhost/concesionario_php/vehiculos.php` para comprobar que funciona
